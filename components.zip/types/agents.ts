import { z } from "zod";

export const ValidatorOutputSchema = z.object({
  projectName: z.string(),
  summary: z.string(),
  keyRequirements: z.array(z.string()),
});

export const ArchitectOutputSchema = z.object({
  architectureOverview: z.string(),
  mainComponents: z.array(z.string()),
  requiredRoles: z.array(z.string()),
});

export const ProjectAnalystOutputSchema = z.object({
  workforceEstimate: z.record(z.string(), z.number()), // role → FTE count
  totalDurationMonths: z.number(),
});

export const HumanResourceOutputSchema = z.object({
  roleRates: z.record(z.string(), z.number()), // role → monthly rate
  totalCost: z.number(),
  notes: z.string().optional(),
});

export const SalesOutputSchema = z.object({
  logo: z.string(),
  date: z.string(),
  to: z.string(),
  from: z.string(),
  subject: z.string(),
  executiveSummary: z.string(),
  assumptions: z.array(z.string()),
  workforceBreakdown: z.array(
    z.object({
      role: z.string(),
      fte: z.number(),
      monthlyRate: z.string(),
      sixMonthCost: z.string(),
    })
  ),
  subtotal: z.string(),
  contingency: z.string(),
  totalCost: z.string(),
  optionsAndNextSteps: z.array(z.string()),
  closing: z.string(),
  contact: z.object({
    name: z.string(),
    title: z.string(),
    email: z.string(),
    phone: z.string(),
  }),
});
