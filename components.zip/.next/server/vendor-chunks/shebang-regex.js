"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/shebang-regex";
exports.ids = ["vendor-chunks/shebang-regex"];
exports.modules = {

/***/ "(action-browser)/./node_modules/shebang-regex/index.js":
/*!*********************************************!*\
  !*** ./node_modules/shebang-regex/index.js ***!
  \*********************************************/
/***/ ((module) => {

eval("\nmodule.exports = /^#!(.*)/;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFjdGlvbi1icm93c2VyKS8uL25vZGVfbW9kdWxlcy9zaGViYW5nLXJlZ2V4L2luZGV4LmpzIiwibWFwcGluZ3MiOiJBQUFhO0FBQ2IiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xccmMwMTVcXERlc2t0b3BcXEV2ZWZ5XFxub2RlX21vZHVsZXNcXHNoZWJhbmctcmVnZXhcXGluZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0Jztcbm1vZHVsZS5leHBvcnRzID0gL14jISguKikvO1xuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6WzBdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(action-browser)/./node_modules/shebang-regex/index.js\n");

/***/ })

};
;