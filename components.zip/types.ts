export type LogDataResult = { message: string };
